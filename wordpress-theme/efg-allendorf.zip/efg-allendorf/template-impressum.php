<?php
/**
 * Template Name: Impressum
 *
 * @package EFG_Allendorf
 */

get_header();

get_template_part( 'template-parts/page-hero', null, array(
	'title'    => 'Impressum',
	'subtitle' => 'Internetauftritt der Evangelischen Freien Gemeinde Allendorf',
	'badge'    => 'Rechtliches',
	'crumbs'   => array( array( 'label' => 'Impressum' ) ),
) );
?>

<section class="section">
	<div class="section-inner">
		<div class="legal-body">

			<div class="legal-address">
				<p>
					<strong>Evangelische Freie Gemeinde Allendorf e.V.</strong><br>
					Heimlingstraße 3<br>
					35753 Greifenstein Allendorf
				</p>
			</div>

			<h2>Angaben gemäß § 5 TMG</h2>
			<p>
				Evangelische Freie Gemeinde Allendorf e.V.<br>
				Heimlingstraße 3<br>
				35753 Greifenstein Allendorf
			</p>
			<p><em>(ehemals Evangelische Gemeinschaft Allendorf bis 09.02.2018)</em></p>
			<p>Vereinsregister am Amtsgericht Wetzlar Nr.: 3618</p>

			<hr class="legal-divider" />

			<h2>Verantwortlich für den Inhalt nach § 55 Abs. 2 RStV</h2>
			<p>
				Florian Diehl, Gemeindeleitung<br>
				Lars Rupp, Vorstand
			</p>

			<hr class="legal-divider" />

			<h2>Spenden</h2>
			<table>
				<tr><td>Konto:</td><td>Evangelische Freie Gemeinde Allendorf</td></tr>
				<tr><td>Bank:</td><td>Sparkasse Wetzlar</td></tr>
				<tr><td>IBAN:</td><td>DE03 5155 0035 0041 3037 44</td></tr>
				<tr><td>BIC:</td><td>HELADEF1WET</td></tr>
			</table>

			<hr class="legal-divider" />

			<h2>Bildernachweis</h2>
			<p>Fotolia.com, Mitarbeiter EFGA</p>

			<hr class="legal-divider" />

			<h2>Haftungsausschluss (Disclaimer)</h2>

			<h3>Allgemeine Informationen</h3>
			<p>Mit Urteil vom 12. Mai 1998 hat das Landgericht Hamburg entschieden, dass man durch die Ausbringung eines Hyperlinks bzw. Links die Inhalte der gelinkten Seite ggf. mit zu verantworten hat. Dies kann nur dadurch verhindert werden, dass man sich ausdrücklich von den Inhalten distanziert. Die Evangelische Freie Gemeinde Allendorf (EFGA) hat auf ihren Internet-Seiten Links zu anderen Seiten gelegt. Für diese Links gilt ausdrücklich, dass wir keinerlei Einfluss auf die Gestaltung und die Inhalte der gelinkten Seiten haben. Deshalb distanzieren wir uns hiermit ausdrücklich von allen Inhalten aller gelinkten Seiten auf unseren Seiten. Diese Erklärung gilt für alle auf unserer Homepage ausgebrachten Links.</p>

			<h3>Inhalt der Website</h3>
			<p>Für die Aktualität, Richtigkeit und Vollständigkeit der bereitgestellten Informationen übernimmt die EFGA keinerlei Gewähr. Haftungsansprüche gegen die EFGA, welche sich auf Schäden materieller oder ideeller Art beziehen, die durch die Nutzung oder Nichtnutzung der dargebotenen Informationen bzw. durch die Nutzung fehlerhafter und unvollständiger Informationen verursacht wurden, sind grundsätzlich ausgeschlossen, sofern seitens der EFGA kein nachweislich vorsätzliches oder grob fahrlässiges Verschulden vorliegt.</p>
			<p>Die EFGA behält sich ausdrücklich vor, Teile der Seiten oder das gesamte Angebot ohne gesonderte Ankündigung zu verändern, zu ergänzen, zu löschen oder die Veröffentlichung zeitweise oder endgültig einzustellen.</p>
			<p>Sofern innerhalb des Internetangebotes die Möglichkeit zur Eingabe persönlicher oder geschäftlicher Daten (E-Mailadressen, Namen, Anschriften) besteht, so erfolgt die Preisgabe dieser Daten seitens des Nutzers auf ausdrücklich freiwilliger Basis.</p>

			<h3>Links auf dieser Website</h3>
			<p>Bei direkten oder indirekten Verweisen auf fremde Internetseiten („Links"), die außerhalb des Verantwortungsbereiches von der EFGA liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem die EFGA von den Inhalten Kenntnis hat und es ihr technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.</p>
			<p>Für illegale, fehlerhafte oder unvollständige Inhalte und insbesondere für Schäden, die aus der Nutzung oder Nichtnutzung solcherart dargebotener Informationen entstehen, haftet allein der Anbieter der Seite, auf welche verwiesen wurde, nicht derjenige, der über Links auf die jeweilige Veröffentlichung lediglich verweist.</p>

			<h3>Urheberrecht</h3>
			<p>Das Copyright für veröffentlichte, von der EFGA selbst erstellte Objekte bleibt allein bei der EFGA.</p>

			<h3>Bildnachweis</h3>
			<p>Das Gemeindefoto auf der Startseite und der Seite „Wer wir sind" ist eine eigene Aufnahme der Gemeinde.</p>
			<p>Die Stimmungsbilder auf den Angebotsseiten sind Stockfotos von <a href="https://www.pexels.com/de-de/" target="_blank" rel="noopener noreferrer">Pexels</a> und stehen unter der <a href="https://www.pexels.com/de-de/lizenz/" target="_blank" rel="noopener noreferrer">Pexels-Lizenz</a>. Sie zeigen keine Mitglieder unserer Gemeinde. Alle Bilder werden von unserem eigenen Server ausgeliefert, es findet keine Verbindung zu Pexels statt.</p>
			<ul>
			    <li>Gottesdienst: Adrien Olichon, Pexels (<a href="https://www.pexels.com/de-de/foto/14975218/" target="_blank" rel="noopener noreferrer">Foto 14975218</a>)</li>
			    <li>Hauskreise: ArtHouse Studio, Pexels (<a href="https://www.pexels.com/de-de/foto/6017728/" target="_blank" rel="noopener noreferrer">Foto 6017728</a>)</li>
			    <li>GLV: Tara Winstead, Pexels (<a href="https://www.pexels.com/de-de/foto/8383495/" target="_blank" rel="noopener noreferrer">Foto 8383495</a>)</li>
			    <li>Bibelstunde: Brett Jordan, Pexels (<a href="https://www.pexels.com/de-de/foto/4747535/" target="_blank" rel="noopener noreferrer">Foto 4747535</a>)</li>
			    <li>Seniorenarbeit: Pexels (<a href="https://www.pexels.com/de-de/foto/17066487/" target="_blank" rel="noopener noreferrer">Foto 17066487</a>)</li>
			    <li>Kaffee und Müsli: Pexels (<a href="https://www.pexels.com/de-de/foto/6036425/" target="_blank" rel="noopener noreferrer">Foto 6036425</a>)</li>
			    <li>Frauengebetskreis: RDNE Stock project, Pexels (<a href="https://www.pexels.com/de-de/foto/10029811/" target="_blank" rel="noopener noreferrer">Foto 10029811</a>)</li>
			    <li>Männertreffen: neslihan, Pexels (<a href="https://www.pexels.com/de-de/foto/34162898/" target="_blank" rel="noopener noreferrer">Foto 34162898</a>)</li>
			    <li>Crossroad: Roza, Pexels (<a href="https://www.pexels.com/de-de/foto/34733337/" target="_blank" rel="noopener noreferrer">Foto 34733337</a>)</li>
			    <li>Wilde Füchse: Dimenshtein Olga, Pexels (<a href="https://www.pexels.com/de-de/foto/9293406/" target="_blank" rel="noopener noreferrer">Foto 9293406</a>)</li>
			    <li>Knallerbsen: Eren Li, Pexels (<a href="https://www.pexels.com/de-de/foto/7168985/" target="_blank" rel="noopener noreferrer">Foto 7168985</a>)</li>
			    <li>Kindergottesdienst: Anastasia Shuraeva, Pexels (<a href="https://www.pexels.com/de-de/foto/6978767/" target="_blank" rel="noopener noreferrer">Foto 6978767</a>)</li>
			    <li>Biblischer Unterricht: Pexels (<a href="https://www.pexels.com/de-de/foto/5124878/" target="_blank" rel="noopener noreferrer">Foto 5124878</a>)</li>
			</ul>

			<h3>Rechtswirksamkeit dieses Haftungsausschlusses</h3>
			<p>Dieser Haftungsausschluss ist als Teil des Internetangebotes zu betrachten, von dem aus auf diese Seite verwiesen wurde. Sofern Teile oder einzelne Formulierungen dieses Textes der geltenden Rechtslage nicht, nicht mehr oder nicht vollständig entsprechen sollten, bleiben die übrigen Teile des Dokumentes in ihrem Inhalt und ihrer Gültigkeit davon unberührt.</p>

		</div>
	</div>
</section>

<?php
get_footer();
